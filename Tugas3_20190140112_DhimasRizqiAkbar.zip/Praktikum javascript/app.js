/*
//alert dari app.js
alert('ini alert dari app.js')

//Confirm dari app.js
confirm('ini confirm dari app.js')

//Console.log
console.log('ini console.log dari app.js)
*/
//Tanggal
Date()
var Tanggal = new Date()
document.getElementById('Tanggal').innerHTML = Tanggal;